package com.fragma.book.dto;

import com.google.gson.annotations.SerializedName;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name="book_details")
@EntityListeners(AuditingEntityListener.class)
public class Book implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long bookid;
    @NotBlank
    @SerializedName("book_name")
    private String book_name;
    @NotNull
    @SerializedName("book_price")
    private Double book_price;
    @NotNull
    @SerializedName("book_release_date")
    private String book_release_date;

    @SerializedName("authorNames")
    @OneToMany(mappedBy="book",cascade = CascadeType.ALL)
   /* @JoinTable(name = "author_name",
            joinColumns = {@JoinColumn(name = "id")},
            inverseJoinColumns = {@JoinColumn(name = "bookid")})*/
    private List<AuthorName> authorNames;

    @NotBlank
    @SerializedName("book_category")
    private String book_category;
    @Column(nullable = false)
    @LastModifiedDate
    private Date updatedAt;

    public Book()
    {

    }
    @Override
    public String toString() {
        return "Book{" +
                "bookid=" + bookid +
                ", book_name='" + book_name + '\'' +
                ", book_price=" + book_price +
                ", book_release_date='" + book_release_date + '\'' +
                ", book_author='" + authorNames + '\'' +
                ", book_category='" + book_category + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }


    public Date getUpdatedAt() {
        return updatedAt;
    }


    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getBookid() {
        return bookid;
    }

    public void setBookid(Long bookid) {
        this.bookid = bookid;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public Double getBook_price() {
        return book_price;
    }

    public void setBook_price(Double book_price) {
        this.book_price = book_price;
    }

    public String getBook_release_date() {
        return book_release_date;
    }

    public void setBook_release_date(String book_release_date) {
        this.book_release_date = book_release_date;
    }

    public List<AuthorName> getAuthorNames() {
        return authorNames;
    }

    public void setAuthorNames(List<AuthorName> authorNames) {
        this.authorNames = authorNames;
    }

    public String getBook_category() {
        return book_category;
    }

    public void setBook_category(String book_category) {
        this.book_category = book_category;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return Objects.equals(bookid, book.bookid) &&
                Objects.equals(book_name, book.book_name) &&
                Objects.equals(book_price, book.book_price) &&
                Objects.equals(book_release_date, book.book_release_date) &&
                Objects.equals(authorNames, book.authorNames) &&
                Objects.equals(book_category, book.book_category) &&
                Objects.equals(updatedAt, book.updatedAt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(bookid, book_name, book_price, book_release_date, authorNames, book_category, updatedAt);
    }
}
