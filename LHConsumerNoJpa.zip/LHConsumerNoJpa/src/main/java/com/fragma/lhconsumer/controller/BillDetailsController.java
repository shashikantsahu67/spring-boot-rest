package com.fragma.lhconsumer.controller;

import com.fragma.lhconsumer.bean.Bill_Details;
import com.fragma.lhconsumer.bean.Payment_Details;
import com.fragma.lhconsumer.dao.BillDetailsDAO;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillDetailsController {

    @RequestMapping("/get")
    public Bill_Details getData(@RequestBody Bill_Details billDetails)
    {

        new BillDetailsDAO().billDetailsDAO(billDetails);
        return billDetails;
    }

}
