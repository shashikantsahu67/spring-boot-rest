package com.fragma.lhconsumer.bean;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Bill_Details {
    @SerializedName("hdoid")
    private String hdoid;
    @SerializedName("rackno")
    private String rackno;
    @SerializedName("address")
    private String address;
    @SerializedName("pincode")
    private String pincode;
    @SerializedName("bookedby")
    private String bookedby;
    @SerializedName("email_id")
    private String email_id;
    @SerializedName("outlet_id")
    private String outlet_id;
    @SerializedName("zomato_id")
    private String zomato_id;
    @SerializedName("reforderno")
    private String reforderno;
    @SerializedName("report_date")
    private String report_date;
    @SerializedName("cust_interst")
    private String cust_interst;
    @SerializedName("payment_done")
    private Boolean payment_done;
    @SerializedName("customer_name")
    private String customer_name;
    @SerializedName("customervcode")
    private String customervcode;
    @SerializedName("paymentstatus")
    private String paymentstatus;
    @SerializedName("pre_order_time")
    private String pre_order_time;
    @SerializedName("payment_details")
    private List<Payment_Details> payment_details;
    @SerializedName("completeorder_id")
    private String completeorder_id;
    @SerializedName("full_ordercancel")
    private Boolean full_ordercancel;
    @SerializedName("customer_phonenum")
    private String customer_phonenum;
    @SerializedName("brand_order_details")
    private List<Brand_Order_Details> brand_order_details;

    @Override
    public String toString() {
        return "Bill_Details{" +
                "hdoid='" + hdoid + '\'' +
                ", rackno='" + rackno + '\'' +
                ", address='" + address + '\'' +
                ", pincode='" + pincode + '\'' +
                ", bookedby='" + bookedby + '\'' +
                ", email_id='" + email_id + '\'' +
                ", outlet_id='" + outlet_id + '\'' +
                ", zomato_id='" + zomato_id + '\'' +
                ", reforderno='" + reforderno + '\'' +
                ", report_date='" + report_date + '\'' +
                ", cust_interst='" + cust_interst + '\'' +
                ", payment_done=" + payment_done +
                ", customer_name='" + customer_name + '\'' +
                ", customervcode='" + customervcode + '\'' +
                ", paymentstatus='" + paymentstatus + '\'' +
                ", pre_order_time='" + pre_order_time + '\'' +
                ", payment_details=" + payment_details +
                ", completeorder_id='" + completeorder_id + '\'' +
                ", full_ordercancel=" + full_ordercancel +
                ", customer_phonenum='" + customer_phonenum + '\'' +
                ", brand_order_details=" + brand_order_details +
                '}';
    }

    public String getCust_interst() {
        return cust_interst;
    }

    public void setCust_interst(String cust_interst) {
        this.cust_interst = cust_interst;
    }

    public Boolean getPayment_done() {
        return payment_done;
    }

    public void setPayment_done(Boolean payment_done) {
        this.payment_done = payment_done;
    }

    public String getHdoid() {
        return hdoid;
    }

    public void setHdoid(String hdoid) {
        this.hdoid = hdoid;
    }

    public String getRackno() {
        return rackno;
    }

    public void setRackno(String rackno) {
        this.rackno = rackno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getBookedby() {
        return bookedby;
    }

    public void setBookedby(String bookedby) {
        this.bookedby = bookedby;
    }

    public String getEmail_id() {
        return email_id;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public String getOutlet_id() {
        return outlet_id;
    }

    public void setOutlet_id(String outlet_id) {
        this.outlet_id = outlet_id;
    }

    public String getZomato_id() {
        return zomato_id;
    }

    public void setZomato_id(String zomato_id) {
        this.zomato_id = zomato_id;
    }

    public String getReforderno() {
        return reforderno;
    }

    public void setReforderno(String reforderno) {
        this.reforderno = reforderno;
    }

    public String getReport_date() {
        return report_date;
    }

    public void setReport_date(String report_date) {
        this.report_date = report_date;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getCustomervcode() {
        return customervcode;
    }

    public void setCustomervcode(String customervcode) {
        this.customervcode = customervcode;
    }

    public String getPaymentstatus() {
        return paymentstatus;
    }

    public void setPaymentstatus(String paymentstatus) {
        this.paymentstatus = paymentstatus;
    }

    public String getPre_order_time() {
        return pre_order_time;
    }

    public void setPre_order_time(String pre_order_time) {
        this.pre_order_time = pre_order_time;
    }

    public List<Payment_Details> getPayment_details() {
        return payment_details;
    }

    public void setPayment_details(List<Payment_Details> payment_details) {
        this.payment_details = payment_details;
    }

    public String getCompleteorder_id() {
        return completeorder_id;
    }

    public void setCompleteorder_id(String completeorder_id) {
        this.completeorder_id = completeorder_id;
    }

    public Boolean getFull_ordercancel() {
        return full_ordercancel;
    }

    public void setFull_ordercancel(Boolean full_ordercancel) {
        this.full_ordercancel = full_ordercancel;
    }

    public String getCustomer_phonenum() {
        return customer_phonenum;
    }

    public void setCustomer_phonenum(String customer_phonenum) {
        this.customer_phonenum = customer_phonenum;
    }

    public List<Brand_Order_Details> getBrand_order_details() {
        return brand_order_details;
    }

    public void setBrand_order_details(List<Brand_Order_Details> brand_order_details) {
        this.brand_order_details = brand_order_details;
    }
}
