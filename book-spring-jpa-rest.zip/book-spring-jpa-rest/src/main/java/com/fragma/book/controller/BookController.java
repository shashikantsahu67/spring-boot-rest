package com.fragma.book.controller;

import com.fragma.book.dto.AuthorName;
import com.fragma.book.dto.Book;
import com.fragma.book.exception.ResourceNotFoundException;
import com.fragma.book.repository.AuthorNameRepository;
import com.fragma.book.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api")
public class BookController {
    @Autowired
    BookRepository bookRepository;

    @Autowired
    AuthorNameRepository authorNameRepository;

    //Find all Books stored inisde database
    @GetMapping("/books")
    public List<Book> getAllBooks()
    {
    return bookRepository.findAll();
    }

    //To store Book in side the database
    @PostMapping("/books")
    public Book createBook(@Valid @RequestBody Book book)
    {
        List<AuthorName> authorName=book.getAuthorNames();
        for (AuthorName authorName1:authorName)
        {
        authorNameRepository.save(authorName1);
        }
        System.out.println(book);
      bookRepository.save(book);
        return book;
    }

    //Delete the book from database by bookId
   @DeleteMapping("/books/{bid}")
   public String deleteBook(@PathVariable (value = "bid") Long bid)
   {
   Book book=bookRepository.findById(bid).orElseThrow(()->new ResourceNotFoundException("Book","bid",bid));
    bookRepository.delete(book);
    return "Book id "+bid+"deleted ....";// ResponseEntity.ok().build();
   }

   //Get the Book by book id from database
   @GetMapping("/books/{bid}")
    public Book getBookById(@PathVariable (value = "bid") Long bid)
   {
       return bookRepository.findById(bid).orElseThrow(()->new ResourceNotFoundException("Book","bid",bid));
   }

   //Put the data or Update the Book by bookId
  /* @PutMapping("/books/{bid}")
   public String updateBookById(@PathVariable(value = "bid") Long bid,@Valid @RequestBody Book books)
   {
    Book book=bookRepository.findById(bid).orElseThrow(()->new ResourceNotFoundException("Book","bid",bid));
    book.setBook_author(books.getBook_author());
    book.setBook_category(books.getBook_category());
    book.setBook_name(books.getBook_name());
    book.setBook_price(books.getBook_price());
    book.setBook_release_date(books.getBook_release_date());
    bookRepository.save(book);
    return "Updated Book "+book.getBook_name();
   }*/
}
