package com.fragma.beans;


import lombok.Data;

import java.util.List;
@Data
public class StudentRegistrationReply {
	private int id;
	private String name;
	private int age;
	private String registrationNumber;
	private String registrationStatus;
	//private List<Student_payment_details> payment_detailsList;
	private Student_payment_details payment_detailsList;

	public Student_payment_details getPayment_detailsList() {
		return payment_detailsList;
	}

	public void setPayment_detailsList(Student_payment_details payment_detailsList) {
		this.payment_detailsList = payment_detailsList;
	}
	//	private String payment_detailsList;

	/*public String getPayment_detailsList() {
		return payment_detailsList;
	}

	public void setPayment_detailsList(String payment_detailsList) {
		this.payment_detailsList = payment_detailsList;
	}*/
/*public List<Student_payment_details> getPayment_detailsList() {
		return payment_detailsList;
	}

	public void setPayment_detailsList(List<Student_payment_details> payment_detailsList) {
		this.payment_detailsList = payment_detailsList;
	}*/

	@Override
	public String toString() {
		return "StudentRegistrationReply{" +
				"name='" + name + '\'' +
				", age=" + age +
				", registrationNumber='" + registrationNumber + '\'' +
				", registrationStatus='" + registrationStatus + '\'' +
				'}';
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
	public String getRegistrationStatus() {
		return registrationStatus;
	}
	public void setRegistrationStatus(String registrationStatus) {
		this.registrationStatus = registrationStatus;
	}
}
