package com.fragma.lhconsumer.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class Payment_Details {

    @SerializedName("change")
    private String change;
    @SerializedName("phcancel")
    private String phcancel;
    @SerializedName("phcounter")
    private String phcounter;
    @SerializedName("phuser_id")
    private Long phuser_id;
    @SerializedName("cardtrannum")
    private String cardtrannum;
    @SerializedName("phuser_name")
    private String phuser_name;
    @SerializedName("payment_bundle")
    @JsonProperty("payment_bundle")
    private List<Payment_Bundle> payment_bundle;
    @SerializedName("cardpaymentdetails")
    private String cardpaymentdetails;

    @Override
    public String toString() {
        return "Payment_Details{" +
                "change='" + change + '\'' +
                ", phcancel='" + phcancel + '\'' +
                ", phcounter='" + phcounter + '\'' +
                ", phuser_id=" + phuser_id +
                ", cardtrannum='" + cardtrannum + '\'' +
                ", phuser_name='" + phuser_name + '\'' +
                ", paymentBundle=" + payment_bundle +
                ", cardpaymentdetails='" + cardpaymentdetails + '\'' +
                '}';
    }

    public String getChange() {
        return change;
    }

    public void setChange(String change) {
        this.change = change;
    }

    public String getPhcancel() {
        return phcancel;
    }

    public void setPhcancel(String phcancel) {
        this.phcancel = phcancel;
    }

    public String getPhcounter() {
        return phcounter;
    }

    public void setPhcounter(String phcounter) {
        this.phcounter = phcounter;
    }

    public Long getPhuser_id() {
        return phuser_id;
    }

    public void setPhuser_id(Long phuser_id) {
        this.phuser_id = phuser_id;
    }

    public String getCardtrannum() {
        return cardtrannum;
    }

    public void setCardtrannum(String cardtrannum) {
        this.cardtrannum = cardtrannum;
    }

    public String getPhuser_name() {
        return phuser_name;
    }

    public void setPhuser_name(String phuser_name) {
        this.phuser_name = phuser_name;
    }

    public List<Payment_Bundle> getPayment_bundle() {
        return payment_bundle;
    }

    public void setPayment_bundle(List<Payment_Bundle> payment_bundle) {
        this.payment_bundle = payment_bundle;
    }

    public String getCardpaymentdetails() {
        return cardpaymentdetails;
    }

    public void setCardpaymentdetails(String cardpaymentdetails) {
        this.cardpaymentdetails = cardpaymentdetails;
    }
}
