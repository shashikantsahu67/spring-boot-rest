package com.fragma.beans;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Student {
	@SerializedName("id")
	private int id;
	@SerializedName("name")
	private String name;
	@SerializedName("age")
	private int age;
	@SerializedName("registrationNumber")
	private String registrationNumber;

	@SerializedName("payment_detailsList")
	private ArrayList<Student_payment_details> payment_detailsList;

	public ArrayList<Student_payment_details> getPayment_detailsList() {
		return payment_detailsList;
	}

	public void setPayment_detailsList(ArrayList<Student_payment_details> payment_detailsList) {
		this.payment_detailsList = payment_detailsList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Student{" +
				"name='" + name + '\'' +
				", age=" + age +
				", registrationNumber='" + registrationNumber + '\'' +
				'}';
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
}
