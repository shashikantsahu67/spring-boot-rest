package com.fragma.lhconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WithoutJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(WithoutJpaApplication.class, args);
    }

}

