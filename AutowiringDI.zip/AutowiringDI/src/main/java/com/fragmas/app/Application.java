package com.fragmas.app;

import com.fragmas.dto.Person;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.fragmas")
public class Application {
    public static void main(String[] args) {
        ConfigurableApplicationContext apc= SpringApplication.run(Application.class, args);
        Person p=apc.getBean(Person.class);
        p.printTest();
    }

}

