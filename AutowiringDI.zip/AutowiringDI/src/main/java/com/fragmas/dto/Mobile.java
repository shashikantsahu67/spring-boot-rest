package com.fragmas.dto;

import org.springframework.stereotype.Component;

@Component("mob")
public class Mobile {
    private String name ;
    private String model;
    public Mobile()
    {
        super();
        System.out.println("Mobile class object created ...");
    }

    public void printData()
    {
        System.out.println("Mobile class methods ....");
    }
    @Override
    public String toString() {
        return "Mobile{" +
                "name='" + name + '\'' +
                ", model='" + model + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}
