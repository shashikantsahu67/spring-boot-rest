package com.fragma.lhconsumer.bean;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Brand_Order_Details {

    @SerializedName("cardno")
    private String cardno;
    @SerializedName("bill_no")
    private Long bill_no;
    @SerializedName("counter")
    private String counter;
    @SerializedName("remarks")
    private String remarks;
    @SerializedName("billedun")
    private String billedun;
    @SerializedName("brand_id")
    private Long brand_id;
    @SerializedName("discount")
    private Double discount;
    @SerializedName("order_no")
    private Long order_no;
    @SerializedName("roundoff")
    private Long roundoff;
    @SerializedName("tokennum")
    private String tokennum;
    @SerializedName("billeduid")
    private Long billeduid;
    @SerializedName("net_total")
    private Double net_total;
    @SerializedName("total_tax")
    private Double total_tax;
    @SerializedName("brand_name")
    private String brand_name;
    @SerializedName("company_id")
    private Long company_id;
    @SerializedName("deviceType")
    private String deviceType;
    @SerializedName("isvoidbill")
    private Boolean isvoidbill;
    @SerializedName("modified_d")
    private String modified_d;
    @SerializedName("order_type")
    private String order_type;
    @SerializedName("total_disc")
    private Double total_disc;
    @SerializedName("total_sale")
    private Double total_sale;
    @SerializedName("voidbillun")
    private String voidbillun;
    @SerializedName("gross_total")
    private Double gross_total;
    @SerializedName("orderuserid")
    private Long orderuserid;
    @SerializedName("tax_details")
    List<Tax_Details> tax_details;
    @SerializedName("voidbilluid")
    private Long voidbilluid;
    @SerializedName("billeduserid")
    private Long billeduserid;
    @SerializedName("company_name")
    private String company_name;
    @SerializedName("itemdiscount")
    private Double itemdiscount;
    @SerializedName("payment_mode")
    private Boolean payment_mode;
    @SerializedName("compartmentno")
    private String compartmentno;
    @SerializedName("order_details")
    List<Order_Details> order_details;
    @SerializedName("orderusername")
    private String orderusername;
    @SerializedName("billedusername")
    private String billedusername;
    @SerializedName("order_taketime")
    private String order_taketime;
    @SerializedName("billed_datetime")
    private String billed_datetime;
    @SerializedName("categorydiscount")
    private Double categorydiscount;
    @SerializedName("order_processing")
    private String order_processing;
    @SerializedName("cancelcountername")
    private String cancelcountername;
    @SerializedName("order_paymenttime")
    private String order_paymenttime;
    @SerializedName("order_acceptedtime")
    private String order_acceptedtime;

    @Override
    public String toString() {
        return "Brand_Order_Details{" +
                "cardno='" + cardno + '\'' +
                ", bill_no=" + bill_no +
                ", counter='" + counter + '\'' +
                ", remarks='" + remarks + '\'' +
                ", billedun='" + billedun + '\'' +
                ", brand_id=" + brand_id +
                ", discount=" + discount +
                ", order_no=" + order_no +
                ", roundoff=" + roundoff +
                ", tokennum='" + tokennum + '\'' +
                ", billeduid=" + billeduid +
                ", net_total=" + net_total +
                ", total_tax=" + total_tax +
                ", brand_name='" + brand_name + '\'' +
                ", company_id=" + company_id +
                ", deviceType='" + deviceType + '\'' +
                ", isvoidbill=" + isvoidbill +
                ", modified_d='" + modified_d + '\'' +
                ", order_type='" + order_type + '\'' +
                ", total_disc=" + total_disc +
                ", total_sale=" + total_sale +
                ", voidbillun='" + voidbillun + '\'' +
                ", gross_total=" + gross_total +
                ", orderuserid=" + orderuserid +
                ", taxDetails=" + tax_details +
                ", voidbilluid=" + voidbilluid +
                ", billeduserid=" + billeduserid +
                ", company_name='" + company_name + '\'' +
                ", itemdiscount=" + itemdiscount +
                ", payment_mode=" + payment_mode +
                ", compartmentno='" + compartmentno + '\'' +
                ", orderDetails=" + order_details +
                ", orderusername='" + orderusername + '\'' +
                ", biledusername='" + billedusername + '\'' +
                ", order_taketime='" + order_taketime + '\'' +
                ", billed_datetime='" + billed_datetime + '\'' +
                ", categorydiscount=" + categorydiscount +
                ", order_processing='" + order_processing + '\'' +
                ", cancelcountername='" + cancelcountername + '\'' +
                ", order_paymenttime='" + order_paymenttime + '\'' +
                ", order_acceptedtime='" + order_acceptedtime + '\'' +
                '}';
    }

    public String getCardno() {
        return cardno;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public Long getBill_no() {
        return bill_no;
    }

    public void setBill_no(Long bill_no) {
        this.bill_no = bill_no;
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getBilledun() {
        return billedun;
    }

    public void setBilledun(String billedun) {
        this.billedun = billedun;
    }

    public Long getBrand_id() {
        return brand_id;
    }

    public void setBrand_id(Long brand_id) {
        this.brand_id = brand_id;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Long getOrder_no() {
        return order_no;
    }

    public void setOrder_no(Long order_no) {
        this.order_no = order_no;
    }

    public Long getRoundoff() {
        return roundoff;
    }

    public void setRoundoff(Long roundoff) {
        this.roundoff = roundoff;
    }

    public String getTokennum() {
        return tokennum;
    }

    public void setTokennum(String tokennum) {
        this.tokennum = tokennum;
    }

    public Long getBilleduid() {
        return billeduid;
    }

    public void setBilleduid(Long billeduid) {
        this.billeduid = billeduid;
    }

    public Double getNet_total() {
        return net_total;
    }

    public void setNet_total(Double net_total) {
        this.net_total = net_total;
    }

    public Double getTotal_tax() {
        return total_tax;
    }

    public void setTotal_tax(Double total_tax) {
        this.total_tax = total_tax;
    }

    public String getBrand_name() {
        return brand_name;
    }

    public void setBrand_name(String brand_name) {
        this.brand_name = brand_name;
    }

    public Long getCompany_id() {
        return company_id;
    }

    public void setCompany_id(Long company_id) {
        this.company_id = company_id;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public Boolean getIsvoidbill() {
        return isvoidbill;
    }

    public void setIsvoidbill(Boolean isvoidbill) {
        this.isvoidbill = isvoidbill;
    }

    public String getModified_d() {
        return modified_d;
    }

    public void setModified_d(String modified_d) {
        this.modified_d = modified_d;
    }

    public String getOrder_type() {
        return order_type;
    }

    public void setOrder_type(String order_type) {
        this.order_type = order_type;
    }

    public Double getTotal_disc() {
        return total_disc;
    }

    public void setTotal_disc(Double total_disc) {
        this.total_disc = total_disc;
    }

    public Double getTotal_sale() {
        return total_sale;
    }

    public void setTotal_sale(Double total_sale) {
        this.total_sale = total_sale;
    }

    public String getVoidbillun() {
        return voidbillun;
    }

    public void setVoidbillun(String voidbillun) {
        this.voidbillun = voidbillun;
    }

    public Double getGross_total() {
        return gross_total;
    }

    public void setGross_total(Double gross_total) {
        this.gross_total = gross_total;
    }

    public Long getOrderuserid() {
        return orderuserid;
    }

    public void setOrderuserid(Long orderuserid) {
        this.orderuserid = orderuserid;
    }

    public Long getVoidbilluid() {
        return voidbilluid;
    }

    public void setVoidbilluid(Long voidbilluid) {
        this.voidbilluid = voidbilluid;
    }

    public Long getBilleduserid() {
        return billeduserid;
    }

    public void setBilleduserid(Long billeduserid) {
        this.billeduserid = billeduserid;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public Double getItemdiscount() {
        return itemdiscount;
    }

    public void setItemdiscount(Double itemdiscount) {
        this.itemdiscount = itemdiscount;
    }

    public Boolean getPayment_mode() {
        return payment_mode;
    }

    public void setPayment_mode(Boolean payment_mode) {
        this.payment_mode = payment_mode;
    }

    public String getCompartmentno() {
        return compartmentno;
    }

    public void setCompartmentno(String compartmentno) {
        this.compartmentno = compartmentno;
    }

    public List<Tax_Details> getTax_details() {
        return tax_details;
    }

    public void setTax_details(List<Tax_Details> tax_details) {
        this.tax_details = tax_details;
    }

    public List<Order_Details> getOrder_details() {
        return order_details;
    }

    public void setOrder_details(List<Order_Details> order_details) {
        this.order_details = order_details;
    }

    public String getOrderusername() {
        return orderusername;
    }

    public void setOrderusername(String orderusername) {
        this.orderusername = orderusername;
    }

    public String getBilledusername() {
        return billedusername;
    }

    public void setBilledusername(String billedusername) {
        this.billedusername = billedusername;
    }

    public String getOrder_taketime() {
        return order_taketime;
    }

    public void setOrder_taketime(String order_taketime) {
        this.order_taketime = order_taketime;
    }

    public String getBilled_datetime() {
        return billed_datetime;
    }

    public void setBilled_datetime(String billed_datetime) {
        this.billed_datetime = billed_datetime;
    }

    public Double getCategorydiscount() {
        return categorydiscount;
    }

    public void setCategorydiscount(Double categorydiscount) {
        this.categorydiscount = categorydiscount;
    }

    public String getOrder_processing() {
        return order_processing;
    }

    public void setOrder_processing(String order_processing) {
        this.order_processing = order_processing;
    }

    public String getCancelcountername() {
        return cancelcountername;
    }

    public void setCancelcountername(String cancelcountername) {
        this.cancelcountername = cancelcountername;
    }

    public String getOrder_paymenttime() {
        return order_paymenttime;
    }

    public void setOrder_paymenttime(String order_paymenttime) {
        this.order_paymenttime = order_paymenttime;
    }

    public String getOrder_acceptedtime() {
        return order_acceptedtime;
    }

    public void setOrder_acceptedtime(String order_acceptedtime) {
        this.order_acceptedtime = order_acceptedtime;
    }
}
