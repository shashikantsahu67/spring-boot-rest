package com.fragma.driver;

import com.fragma.controller.FileWritter;

public class PlaneCrashCsvwriter {
    public static void main(String ar[]) {
        //HashMap<Integer, PlaneCrashInfo> infoHashMap =new HashMap<Integer, PlaneCrashInfo>();
        System.out.println("Start");
       //new FileWritter().readNationalities();
        //Map<Integer,String> countryMop=new FileWritter().getContriesFromString();
        new FileWritter().writeInCsv();

        System.out.println("end");
    }
}
