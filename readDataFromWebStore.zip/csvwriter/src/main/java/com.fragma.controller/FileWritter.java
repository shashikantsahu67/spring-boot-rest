package com.fragma.controller;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.fragma.bean.PlaneCrashInfo;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.*;

public class FileWritter {
    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";
    private static final String FILE_HEADER = "id,Date,Location/Operator,Aircraft Type/Registration,Country or City ,DeadPassanger,TotalPassanger";
    public HashMap<Integer, PlaneCrashInfo> writeCsvFile() {
        FileWriter fileWriter;
        String file = "C:\\Users\\LENOVO\\Documents\\planecrashinfo.csv";
        PlaneCrashInfo planeCrashInfo = null;
        HashMap<Integer, PlaneCrashInfo> hashMap = new HashMap<Integer, PlaneCrashInfo>();
        //  List<PlaneCrashInfo> crashInfoList=new ArrayList<PlaneCrashInfo>();
        int AlPass = 0;
        int index = 1;
        try {
            fileWriter = new FileWriter(file);
            fileWriter.append(FILE_HEADER);
            fileWriter.append(NEW_LINE_SEPARATOR);
            for (int j = 1920; j <= 2019; j++) {
                String url = "http://www.planecrashinfo.com/" + j + "/" + j + ".htm";
                Document doc = Jsoup.connect(url).get();
                Element table = doc.select("table").get(0); //select the first table.
                Elements rows = table.select("tr");
                SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy");
                for (int i = 1; i < rows.size(); i++) { //first row is the col names so skip it.
                    Element row = rows.get(i);
                    Elements cols = row.select("td");
                    String fatal = cols.get(3).text();
                    String[] Pass = fatal.split("/", 2);
                    int DPass = 0;
                    String APass = Pass[1];
                    String[] AllPass = APass.split("\\(", 2);
                    String date = cols.get(0).text();
                    Date d = formatter.parse(date);
                    if (AllPass[0].trim().equals("?") || Pass[0].trim().equals("?")) {
                        AlPass = 0;
                        DPass = 0;

                    } else {
                        AlPass = Integer.parseInt(AllPass[0]);
                        DPass = Integer.parseInt(Pass[0]);
                    }
                    planeCrashInfo = new PlaneCrashInfo(d, cols.get(1).text(), cols.get(2).text(), DPass, AlPass);
                    hashMap.put(index, planeCrashInfo);
                   /* fileWriter.append(String.valueOf(index));
                    fileWriter.append(COMMA_DELIMITER);
                    fileWriter.append(cols.get(0).text());
                    fileWriter.append(COMMA_DELIMITER);
                    fileWriter.append(cols.get(1).text().replaceAll(",", "/"));
                    fileWriter.append(COMMA_DELIMITER);
                    fileWriter.append(cols.get(2).text().replaceAll("\\?", ""));
                    fileWriter.append(COMMA_DELIMITER);
                    fileWriter.append(String.valueOf(DPass));
                    fileWriter.append(COMMA_DELIMITER);
                    fileWriter.append(String.valueOf(AlPass));
                    fileWriter.append(NEW_LINE_SEPARATOR);*/
                    index++;
                   // System.out.println(cols.get(0).text());
                }
                // index++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException nu) {

        } catch (ParseException p) {
            p.printStackTrace();
        }
        return hashMap;
    }
  /* public void pirnt()
   {
       HashMap<Integer,PlaneCrashInfo> hashMap=new FileWritter().writeCsvFile();
       Set<Integer> keySet=hashMap.keySet();
       Iterator<Integer> iterator=keySet.iterator();
       while (iterator.hasNext())
       {
           Integer key= iterator.next();
           System.out.println(key+" "+hashMap.get(key));
       }
   }*/
    public void writeInCsv() {
        HashMap<Integer, PlaneCrashInfo> cityAndCountryMap = new FileWritter().writeCsvFile();
        Map<Integer, String> countryIdWithName = new FileWritter().getContriesFromString();

        Set<Integer> keySet=cityAndCountryMap.keySet();
        Iterator<Integer> iterator=keySet.iterator();
        while (iterator.hasNext())
        {
            Integer key= iterator.next();
            System.out.println(key+" "+cityAndCountryMap.get(key));
        }
        /*FileWriter fileWriter;
        String file = "C:\\Users\\LENOVO\\Documents\\planecrashinfo.csv";
        //PlaneCrashInfo planeCrashInfo = null;
        HashMap<Integer, PlaneCrashInfo> hashMap = new HashMap<Integer, PlaneCrashInfo>();
          List<PlaneCrashInfo> crashInfoList=new ArrayList<PlaneCrashInfo>();
        int AlPass = 0;
        int index = 1;
        try {
            fileWriter = new FileWriter(file);
            fileWriter.append(FILE_HEADER);
            fileWriter.append(NEW_LINE_SEPARATOR);

            Set<Integer> cityAndCountryKey = cityAndCountryMap.keySet();
            Iterator<Integer> iterator = cityAndCountryKey.iterator();
            while (iterator.hasNext()) {
                Integer key = iterator.next();
                PlaneCrashInfo planeCrashInfoData = cityAndCountryMap.get(key);
                String countryName = countryIdWithName.get(key);
                DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
                String strDate = dateFormat.format(planeCrashInfoData.getDate());
                fileWriter.append(String.valueOf(index));
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(strDate);
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(planeCrashInfoData.getLocationOrOperator());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(planeCrashInfoData.getAircraftTypeRegistration());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(planeCrashInfoData.getAircraftTypeRegistration());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(countryName);
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(String.valueOf(planeCrashInfoData.getDeadPassanger()));
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(String.valueOf(planeCrashInfoData.getTotalpassanger()));
                fileWriter.append(NEW_LINE_SEPARATOR);
                index++;
                // System.out.println(cols.get(0).text());

                // index++;

            }
        }catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException nu) {

        }*/

    }


    public List<String> readCountries()
    {
        List<String> countryList=new ArrayList<String>();
        String file="C:\\Users\\LENOVO\\Downloads\\country-city-and-state-csv\\countries.csv";
        try {
            // Create an object of file reader class with CSV file as a parameter.
            FileReader filereader = new FileReader(file);
            CSVParser parser = new CSVParserBuilder().withSeparator(';').build();
            CSVReader csvReader = new CSVReaderBuilder(filereader)
                    .withCSVParser(parser)
                    .build();
            List<String[]> allData = csvReader.readAll();
            for (String[] row : allData) {
                for (String cell : row) {
                    countryList.add(cell.trim());
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return countryList;
    }
    public List<String> readNationalities()
    {
        List<String> nationalityList=new ArrayList<String>();
        int i=0;
        String file="C:\\Users\\LENOVO\\Documents\\CountriesAndNationalities.csv";
        try {
            // Create an object of file reader class with CSV file as a parameter.
            FileReader filereader = new FileReader(file);
            CSVParser parser = new CSVParserBuilder().withSeparator(';').build();
            CSVReader csvReader = new CSVReaderBuilder(filereader).withCSVParser(parser).build();
            List<String[]> allData = csvReader.readAll();
            for (String[] row : allData) {
                for (String cell : row) {
                    if (i==0){
                    }else {
                        nationalityList.add(cell);
                    }
                    i++;
                }
                System.out.println();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return nationalityList;
    }
    public List<String> readCities()
    {
        List<String> cityList=new ArrayList<String>();
        String file="C:\\Users\\LENOVO\\Downloads\\country-city-and-state-csv\\cities.csv";
        try {
            // Create an object of file reader class with CSV file as a parameter.
            FileReader filereader = new FileReader(file);
            CSVParser parser = new CSVParserBuilder().withSeparator(';').build();
            CSVReader csvReader = new CSVReaderBuilder(filereader).withCSVParser(parser).build();
            List<String[]> allData = csvReader.readAll();
            for (String[] row : allData) {
                for (String cell : row) {
                    cityList.add(cell.trim());
                }
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return cityList;
    }
    public Map<Integer,String> getContriesFromString()
    {
      HashMap<Integer,PlaneCrashInfo> crashInfoHashMap=new FileWritter().writeCsvFile();
      List<String> countryList=new FileWritter().readCountries();
      List<String> nationalityList=new FileWritter().readNationalities();
      HashMap<Integer,String> idAndCountryMap=new HashMap<Integer, String>();
        Set<Integer> setOfKeys= crashInfoHashMap.keySet();
        Iterator<Integer> iterator=setOfKeys.iterator();
        List<String> cityList=new FileWritter().readCities();
        int count =0;
        while(iterator.hasNext())
        {
            Integer key=iterator.next();
            String locationOrOperator = crashInfoHashMap.get(key).getLocationOrOperator();
            String [] locaOrOperator= locationOrOperator.split(" ");
            for (int i=0;i<locaOrOperator.length;i++)
            {
               Iterator<String> cityItr=cityList.iterator();
               Iterator<String> countryItr=countryList.iterator();
               Iterator<String> nationalityItr=nationalityList.iterator();
               while( (countryItr.hasNext() && cityItr.hasNext())|| nationalityItr.hasNext())
                   if (countryItr.hasNext()) {
                       String countryName = countryItr.next();
                       if (locaOrOperator[i].contains(countryName)) {
                     //      System.out.println(key + "  " + countryName);
                           String cname=countryName+" CN";
                           idAndCountryMap.put(key,cname);
                           count++;
                       }
                   }
               else if (nationalityItr.hasNext()) {
                       String nationalityRow = nationalityItr.next();
                       String[] countryAndNationality = nationalityRow.split(",");
                       String nationality = countryAndNationality[1];
                       String country = countryAndNationality[0];
                       if (locaOrOperator[i].contains(nationality.trim())) {
                           //System.out.println(key +" " + country);
                           String cname= country+" CNL";
                           idAndCountryMap.put(key,cname);
                           count++;
                       }
                   } else if (cityItr.hasNext()) {
                       String cityName = cityItr.next().trim();
                       String cname=cityName+" CT";
                       if (locaOrOperator[i].contains(cityName))
                           //System.out.println(key + " " + cityName);
                           idAndCountryMap.put(key,cname);
                       count++;
                   }
            }
        }
         System.out.println("count ="+count);
        return  idAndCountryMap;
    }
}
