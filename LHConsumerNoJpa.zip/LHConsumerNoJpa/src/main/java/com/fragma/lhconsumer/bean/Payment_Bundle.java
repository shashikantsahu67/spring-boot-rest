package com.fragma.lhconsumer.bean;
import com.google.gson.annotations.SerializedName;

public class Payment_Bundle {
    @SerializedName("cash")
    private Double cash;
    @SerializedName("card_payment")
    private Double card_payment;

    @Override
    public String toString() {
        return "Payment_Bundle{" +
                "cash=" + cash +
                ", card_payment=" + card_payment +
                '}';
    }

    public Double getCash() {
        return cash;
    }

    public void setCash(Double cash) {
        this.cash = cash;
    }

    public Double getCard_payment() {
        return card_payment;
    }

    public void setCard_payment(Double card_payment) {
        this.card_payment = card_payment;
    }
}
