package com.fragma.lhconsumer.dao;

import com.fasterxml.uuid.Generators;
import com.fragma.lhconsumer.bean.*;

import java.sql.*;
import java.util.List;
import java.util.UUID;

public class BillDetailsDAO {
    private Connection connect = null;
    private PreparedStatement preparedStatement = null;

    public Connection connectToDatabase() {
        try {
            connect = DriverManager
                    .getConnection("jdbc:mysql://localhost/lhconsumer?user=root&password=shashi218");
            System.out.println("connected..........");


        } catch (Exception e) {
            System.out.println(e);
        }
        return connect;
    }

    public void billDetailsDAO(Bill_Details bill_details) {
        UUID uuid1 = Generators.timeBasedGenerator().generate();
        String uuid = uuid1.toString();
        Connection con = new BillDetailsDAO().connectToDatabase();
        String query = "insert into BILL_DETAILS(bill_id, hdoid ,rackno ,address ,pincode,bookedby ,email_id ," +
                "outlet_id ,zomato_id ,reforderno ,report_date ,cust_interst,payment_done," +
                "customer_name ,customervcode ,paymentstatus , pre_order_time ,completeorder_id ,full_ordercancel" +
                " ,customer_phonenum )values (?, ?, ?, ? , ?, ?, ?, ?, ?, ? , ?, ?, ?, ? , ?, ?,?, ?,?,?)";
        try {
            preparedStatement = con
                    .prepareStatement(query);
            con.setAutoCommit(false);
            preparedStatement.setString(1, uuid);
            preparedStatement.setString(2, bill_details.getHdoid());
            preparedStatement.setString(3, bill_details.getRackno());
            preparedStatement.setString(4, bill_details.getAddress());
            preparedStatement.setString(5, bill_details.getPincode());
            preparedStatement.setString(6, bill_details.getBookedby());
            preparedStatement.setString(7, bill_details.getEmail_id());
            preparedStatement.setString(8, bill_details.getOutlet_id());
            preparedStatement.setString(9, bill_details.getZomato_id());
            preparedStatement.setString(10, bill_details.getReforderno());
            preparedStatement.setString(11, bill_details.getReport_date());
            preparedStatement.setString(12, bill_details.getCust_interst());
            preparedStatement.setBoolean(13, bill_details.getPayment_done());
            preparedStatement.setString(14, bill_details.getCustomer_name());
            preparedStatement.setString(15, bill_details.getCustomervcode());
            preparedStatement.setString(16, bill_details.getPaymentstatus());
            preparedStatement.setString(17, bill_details.getPre_order_time());
            preparedStatement.setString(18, bill_details.getCompleteorder_id());
            preparedStatement.setBoolean(19, bill_details.getFull_ordercancel());
            preparedStatement.setString(20, bill_details.getCustomer_phonenum());
            preparedStatement.addBatch();


            List<Payment_Details> payment_detailsList = bill_details.getPayment_details();
            List<Brand_Order_Details> brand_order_details = bill_details.getBrand_order_details();
            new BillDetailsDAO().paymentDetailsDAO(payment_detailsList, uuid, con);
            new BillDetailsDAO().brandOrderDetailsDAO(brand_order_details, uuid, con);

        } catch (SQLException e) {
            System.out.println(e);

        }
        try {
            preparedStatement.executeBatch();
            con.commit();
            System.out.println("Bill Details Data inserted to database ............");
        }catch (SQLException sq){System.out.println(sq);}


    }

    public void brandOrderDetailsDAO(List<Brand_Order_Details> brand_order_details, String uuid, Connection conn) {
        String query = "insert into BRAND_ORDER_DETAILS(bill_id ,cardno ,bill_no ,counter ,remarks ,billedun ,brand_id ," +
                "discount ,order_no , roundoff , tokennum , billeduid ,net_total , total_tax , brand_name , company_id ," +
                " deviceType , isvoidbill ,modified_date , order_type , total_disc , total_sale , voidbillun ,gross_total , " +
                "orderuserid , voidbilluid , billeduserid , company_name , itemdiscount , payment_mode, compartmentno , " +
                "orderusername , billedusername , order_taketime , billed_datetime , categorydiscount , order_processing , " +
                "cancelcountername , order_paymenttime , order_acceptedtime)values (?, ?, ?, ? , ?, ?, ?, ?, ?, ? , ?, ?, ?," +
                " ? , ?, ?,?, ?,?,?, ?,?, ?,?,?, ?,?, ?,?,?, ?,?, ?,?,?,?,?,?,?,?)";

        try {
            preparedStatement = conn
                    .prepareStatement(query);
            conn.setAutoCommit(false);

            for (Brand_Order_Details brand_order_details1 : brand_order_details) {
                preparedStatement.setString(1, uuid);
                preparedStatement.setString(2, brand_order_details1.getCardno());
                preparedStatement.setLong(3, brand_order_details1.getBill_no());
                preparedStatement.setString(4, brand_order_details1.getCounter());
                preparedStatement.setString(5, brand_order_details1.getRemarks());
                preparedStatement.setString(6, brand_order_details1.getBilledun());
                preparedStatement.setLong(7, brand_order_details1.getBrand_id());
                preparedStatement.setDouble(8, brand_order_details1.getDiscount());
                preparedStatement.setLong(9, brand_order_details1.getOrder_no());
                preparedStatement.setLong(10, brand_order_details1.getRoundoff());
                preparedStatement.setString(11, brand_order_details1.getTokennum());
                preparedStatement.setLong(12, brand_order_details1.getBilleduid());
                preparedStatement.setDouble(13, brand_order_details1.getNet_total());
                preparedStatement.setDouble(14, brand_order_details1.getTotal_tax());
                preparedStatement.setString(15, brand_order_details1.getBrand_name());
                preparedStatement.setLong(16, brand_order_details1.getCompany_id());
                preparedStatement.setString(17, brand_order_details1.getDeviceType());
                preparedStatement.setBoolean(18, brand_order_details1.getIsvoidbill());
                preparedStatement.setString(19, brand_order_details1.getModified_d());
                preparedStatement.setString(20, brand_order_details1.getOrder_type());
                preparedStatement.setDouble(21, brand_order_details1.getTotal_disc());
                preparedStatement.setDouble(22, brand_order_details1.getTotal_sale());
                preparedStatement.setString(23, brand_order_details1.getVoidbillun());
                preparedStatement.setDouble(24, brand_order_details1.getGross_total());
                preparedStatement.setDouble(25, brand_order_details1.getOrderuserid());
                preparedStatement.setLong(26, brand_order_details1.getVoidbilluid());
                preparedStatement.setLong(27, brand_order_details1.getBilleduserid());
                preparedStatement.setString(28, brand_order_details1.getCompany_name());
                preparedStatement.setDouble(29, brand_order_details1.getItemdiscount());
                preparedStatement.setBoolean(30, brand_order_details1.getPayment_mode());
                preparedStatement.setString(31, brand_order_details1.getCompartmentno());
                preparedStatement.setString(32, brand_order_details1.getOrderusername());
                preparedStatement.setString(33, brand_order_details1.getBilledusername());
                preparedStatement.setString(34, brand_order_details1.getOrder_taketime());
                preparedStatement.setString(35, brand_order_details1.getBilled_datetime());
                preparedStatement.setDouble(36, brand_order_details1.getCategorydiscount());
                preparedStatement.setString(37, brand_order_details1.getOrder_processing());
                preparedStatement.setString(38, brand_order_details1.getCancelcountername());
                preparedStatement.setString(39, brand_order_details1.getOrder_paymenttime());
                preparedStatement.setString(40, brand_order_details1.getOrder_acceptedtime());
                preparedStatement.addBatch();

                List<Order_Details> order_details = brand_order_details1.getOrder_details();
                new BillDetailsDAO().orderDetailsDAO(order_details, uuid, conn);

                List<Tax_Details> tax_details = brand_order_details1.getTax_details();
                new BillDetailsDAO().taxDetailsDAO(tax_details, uuid, conn);
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
        try {
            preparedStatement.executeBatch();
            conn.commit();
            System.out.println("Brand Order Details Data inserted to database ............");
        }catch (SQLException sq){System.out.println(sq);}
    }

    public void itemTaxDetailsDAO(List<Item_Tax_Details> itemTaxDetailsList, String uuid, Connection conn) {
        String query = "insert into Item_Tax_Details(bill_id, cgst ,sgst)values (?, ?, ?)";

        for (Item_Tax_Details item_tax_details : itemTaxDetailsList) {
            try {
                preparedStatement = conn
                        .prepareStatement(query);
                conn.setAutoCommit(false);
                preparedStatement.setString(1, uuid);
                preparedStatement.setDouble(2, item_tax_details.getCgst());
                preparedStatement.setDouble(3, item_tax_details.getSgst());
                preparedStatement.addBatch();

            } catch (SQLException e) {
                //System.out.println(e);
                e.printStackTrace();
            }
            try {
                preparedStatement.executeBatch();
                conn.commit();
                System.out.println("Item Tax Details Data inserted to database ............");
            }catch (SQLException sq){System.out.println(sq);}

        }

    }

    public void orderDetailsDAO(List<Order_Details> order_details, String uuid, Connection conn) {
        String query = "insert into ORDER_DETAILS(bill_id,cancel,itemqty , remarks , brand_id ,itemcode ,itemname ,baseprice , " +
                "dish_type , is_cancel , itemprice , brand_name ,catdiscamt , company_id , billdiscamt , is_discount, itemdiscamt ," +
                " ordered_qty , totaltaxamt , company_name , is_open_item , cancelled_qty , itemgrossprice , dish_category_id ," +
                " main_category_id , cancel_item_userid , dish_category_name , main_category_name , net_itemtotalprice , " +
                "cancel_item_remarks , cancel_item_user_name )values (?, ?, ?, ? , ?, ?, ?, ?, ?, ? , ?, ?, ?," +
                " ? , ?, ?,?, ?,?,?, ?,?, ?,?,?, ?,?, ?,?,?,?)";
        try {
            preparedStatement = conn
                    .prepareStatement(query);
            conn.setAutoCommit(false);

            for (Order_Details order_details1 : order_details) {
                preparedStatement.setString(1, uuid);
                preparedStatement.setBoolean(2, order_details1.getCancel());
                preparedStatement.setLong(3, order_details1.getItemqty());
                preparedStatement.setString(4, order_details1.getRemarks());
                preparedStatement.setLong(5, order_details1.getBrand_id());
                preparedStatement.setLong(6, order_details1.getItemcode());
                preparedStatement.setString(7, order_details1.getItemname());
                preparedStatement.setDouble(8, order_details1.getBaseprice());
                preparedStatement.setString(9, order_details1.getDish_type());
                preparedStatement.setBoolean(10, order_details1.getIs_cancel());
                preparedStatement.setDouble(11, order_details1.getItemprice());
                preparedStatement.setString(12, order_details1.getBrand_name());
                preparedStatement.setDouble(13, order_details1.getCatdiscamt());
                preparedStatement.setLong(14, order_details1.getCompany_id());
                preparedStatement.setDouble(15, order_details1.getBilldiscamt());
                preparedStatement.setBoolean(16, order_details1.getIs_discount());
                preparedStatement.setDouble(17, order_details1.getItemdiscamt());
                preparedStatement.setLong(18, order_details1.getOrdered_qty());
                preparedStatement.setDouble(19, order_details1.getTotaltaxamt());
                preparedStatement.setString(20, order_details1.getCompany_name());
                preparedStatement.setBoolean(21, order_details1.getIs_open_item());
                preparedStatement.setDouble(22, order_details1.getCancelled_qty());
                preparedStatement.setDouble(23, order_details1.getItemgrossprice());
                preparedStatement.setLong(24, order_details1.getDish_category_id());
                preparedStatement.setLong(25, order_details1.getMain_category_id());
                preparedStatement.setLong(26, order_details1.getCancel_item_userid());
                preparedStatement.setString(27, order_details1.getDish_category_name());
                preparedStatement.setString(28, order_details1.getMain_category_name());
                preparedStatement.setDouble(29, order_details1.getNet_itemtotalprice());
                preparedStatement.setString(30, order_details1.getCancel_item_remarks());
                preparedStatement.setString(31, order_details1.getCancel_item_user_name());
                preparedStatement.addBatch();

                List<Item_Tax_Details> item_tax_details = order_details1.getItem_tax_details();
               new BillDetailsDAO().itemTaxDetailsDAO(item_tax_details, uuid, conn);

            }

        } catch (SQLException e) {
            System.out.println(e);
        }
        try {
            preparedStatement.executeBatch();
            conn.commit();
            System.out.println("Order Details Data inserted to database ............");
        }catch (SQLException sq){System.out.println(sq);}


    }

    public void paymentDetailsDAO(List<Payment_Details> payment_details, String uuid, Connection conn) {

        String query = "insert into PAYMENT_DETAILS(bill_id ,changes,phcancel,phcounter ,phuser_id,cardtrannum ,phuser_name,cardpaymentdetails ) values(?, ?, ?, ?, ?, ?, ?, ?)";

        for (Payment_Details payment_details1 : payment_details) {
            try {
                preparedStatement = conn
                        .prepareStatement(query);
                conn.setAutoCommit(false);
                preparedStatement.setString(1, uuid);
                preparedStatement.setString(2, payment_details1.getChange());
                preparedStatement.setString(3, payment_details1.getPhcancel());
                preparedStatement.setString(4, payment_details1.getPhcounter());
                preparedStatement.setLong(5, payment_details1.getPhuser_id());
                preparedStatement.setString(6, payment_details1.getCardtrannum());
                preparedStatement.setString(7, payment_details1.getPhuser_name());
                preparedStatement.setString(8, payment_details1.getCardpaymentdetails());
                preparedStatement.addBatch();

                List<Payment_Bundle> paymentBundleList = payment_details1.getPayment_bundle();
                new BillDetailsDAO().paymentBundleDAO(paymentBundleList, uuid, conn);
            } catch (SQLException e) {
                System.out.println(e);
            }
            try {
                preparedStatement.executeBatch();
                conn.commit();
                System.out.println("Payment Details Data inserted to database ............");
            }catch (SQLException sq){System.out.println(sq);}

        }
    }

    public void paymentBundleDAO(List<Payment_Bundle> payment_bundlesList, String uuid, Connection conn) {
        String query = "insert into Payment_Bundle(bill_id, cash ,card_payment) values (?, ?, ?)";

        for (Payment_Bundle payment_bundle : payment_bundlesList) {
            try {
                preparedStatement = conn
                        .prepareStatement(query);
                conn.setAutoCommit(false);
                preparedStatement.setString(1, uuid);
                preparedStatement.setDouble(2, payment_bundle.getCash());
                preparedStatement.setDouble(3, payment_bundle.getCard_payment());
                preparedStatement.addBatch();
            } catch (SQLException e) {
                System.out.println(e);
            }
            try {
                preparedStatement.executeBatch();
                conn.commit();
                System.out.println("Payment Bundle Data inserted to database ............");
            }catch (SQLException sq){System.out.println(sq);}

        }

    }

    public void taxDetailsDAO(List<Tax_Details> taxDetailsList, String uuid, Connection conn) {
        String query = "insert into tax_details(bill_id, cgst ,sgst)values (?, ?, ?)";

        for (Tax_Details tax_details : taxDetailsList) {
            try {
                preparedStatement = conn
                        .prepareStatement(query);
                conn.setAutoCommit(false);
                preparedStatement.setString(1, uuid);
                preparedStatement.setString(2, tax_details.getCGST_2());
                preparedStatement.setString(3, tax_details.getSGST_2());
                preparedStatement.addBatch();
            } catch (SQLException e) {
                System.out.println(e);
            }
            try {
                preparedStatement.executeBatch();
                conn.commit();
                System.out.println("Tax Details Data inserted to database ............");
            }catch (SQLException sq){System.out.println(sq);}

        }
    }

}