package com.fragma.driver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages = {"com.fragma"})
public class JsontestrequestApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsontestrequestApplication.class, args);
    }

}

