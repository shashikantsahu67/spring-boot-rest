package com.fragma.beans;

import lombok.Data;

@Data
public class Student_payment_details {
    private int pay;
    private String date;
    private String phcounter;

    public int getPay() {
        return pay;
    }

    @Override
    public String toString() {
        return "Student_payment_details{" +
                "pay=" + pay +
                ", date='" + date + '\'' +
                ", phcounter='" + phcounter + '\'' +
                '}';
    }

    public void setPay(int pay) {
        this.pay = pay;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPhcounter() {
        return phcounter;
    }

    public void setPhcounter(String phcounter) {
        this.phcounter = phcounter;
    }

    public Student_payment_details(int pay, String date, String phcounter) {
        this.pay = pay;
        this.date = date;
        this.phcounter = phcounter;
    }
}
