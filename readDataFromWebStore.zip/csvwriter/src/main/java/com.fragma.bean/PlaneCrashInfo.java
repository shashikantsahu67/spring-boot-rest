package com.fragma.bean;

import java.util.Date;
import java.util.Random;

public class PlaneCrashInfo {

    private Date date ;
    private String LocationOrOperator;
    private String AircraftTypeRegistration;
    private int deadPassanger;
    private int totalpassanger;

    @Override
    public String toString() {
        return "PlaneCrashInfo{" +
                "date=" + date +
                ", LocationOrOperator='" + LocationOrOperator + '\'' +
                ", AircraftTypeRegistration='" + AircraftTypeRegistration + '\'' +
                ", deadPassanger=" + deadPassanger +
                ", totalpassanger=" + totalpassanger +
                '}';
    }

    public PlaneCrashInfo(Date date, String locationOrOperator, String aircraftTypeRegistration, int deadPassanger, int totalpassanger) {
        this.date = date;
        LocationOrOperator = locationOrOperator;
        AircraftTypeRegistration = aircraftTypeRegistration;
        this.deadPassanger = deadPassanger;
        this.totalpassanger = totalpassanger;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLocationOrOperator() {
        return LocationOrOperator;
    }

    public void setLocationOrOperator(String locationOrOperator) {
        LocationOrOperator = locationOrOperator;
    }

    public String getAircraftTypeRegistration() {
        return AircraftTypeRegistration;
    }

    public void setAircraftTypeRegistration(String aircraftTypeRegistration) {
        AircraftTypeRegistration = aircraftTypeRegistration;
    }

    public int getDeadPassanger() {
        return deadPassanger;
    }

    public void setDeadPassanger(int deadPassanger) {
        this.deadPassanger = deadPassanger;
    }

    public int getTotalpassanger() {
        return totalpassanger;
    }

    public void setTotalpassanger(int totalpassanger) {
        this.totalpassanger = totalpassanger;
    }


}
