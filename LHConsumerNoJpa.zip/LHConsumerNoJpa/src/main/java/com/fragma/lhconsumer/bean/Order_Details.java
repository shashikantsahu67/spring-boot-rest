package com.fragma.lhconsumer.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Order_Details {
    @SerializedName("cancel")
    private Boolean cancel;
    @SerializedName("itemqty")
    private Integer itemqty;
    @SerializedName("remarks")
    private String remarks;
    @SerializedName("brand_id")
    private Long brand_id;
    @SerializedName("itemcode")
    private Long itemcode;
    @SerializedName("itemname")
    private String itemname;
    @SerializedName("baseprice")
    private Double baseprice;
    @SerializedName("dish_type")
    private String dish_type;
    @SerializedName("is_cancel")
    private Boolean is_cancel;
    @SerializedName("itemprice")
    private Double itemprice;
    @SerializedName("brand_name")
    private String  brand_name;
    @SerializedName("catdiscamt")
    private Double catdiscamt;
    @SerializedName("company_id")
    private Long company_id;
    @SerializedName("billdiscamt")
    private Double billdiscamt;
    @SerializedName("is_discount")
    private Boolean is_discount;
    @SerializedName("itemdiscamt")
    private Double itemdiscamt;
    @SerializedName("ordered_qty")
    private Long ordered_qty;
    @SerializedName("totaltaxamt")
    private Double totaltaxamt;
    @SerializedName("company_name")
    private String company_name;
    @SerializedName("is_open_item")
    private Boolean is_open_item;
    @SerializedName("cancelled_qty")
    private Long cancelled_qty;
    @SerializedName("litemgrossprice")
    private Double itemgrossprice;
    @SerializedName("dish_category_id")
    private Long dish_category_id;
    @SerializedName("item_tax_details")
    List<Item_Tax_Details> item_tax_details;
    @SerializedName("main_category_id")
    private Long main_category_id;
    @SerializedName("cancel_item_userid")
    private Long cancel_item_userid;
    @SerializedName("dish_category_name")
    private String dish_category_name;
    @SerializedName("main_category_name")
    private String main_category_name;
    @SerializedName("net_itemtotalprice")
    private Double net_itemtotalprice;
    @SerializedName("cancel_item_remarks")
    private String cancel_item_remarks;
    @SerializedName("cancel_item_user_name")
    private String cancel_item_user_name;

    @Override
    public String toString() {
        return "Order_Details{" +
                "cancel=" + cancel +
                ", itemqty=" + itemqty +
                ", remarks='" + remarks + '\'' +
                ", brand_id=" + brand_id +
                ", itemcode=" + itemcode +
                ", itemname='" + itemname + '\'' +
                ", baseprice=" + baseprice +
                ", dish_type='" + dish_type + '\'' +
                ", is_cancel=" + is_cancel +
                ", itemprice=" + itemprice +
                ", brand_name='" + brand_name + '\'' +
                ", catdiscamt=" + catdiscamt +
                ", company_id=" + company_id +
                ", billdiscamt=" + billdiscamt +
                ", is_discount=" + is_discount +
                ", itemdiscamt=" + itemdiscamt +
                ", ordered_qty=" + ordered_qty +
                ", totaltaxamt=" + totaltaxamt +
                ", company_name='" + company_name + '\'' +
                ", is_open_item=" + is_open_item +
                ", cancelled_qty=" + cancelled_qty +
                ", itemgrossprice=" + itemgrossprice +
                ", dish_category_id=" + dish_category_id +
                ", itemTaxDetails=" + item_tax_details +
                ", main_category_id=" + main_category_id +
                ", cancel_item_userid=" + cancel_item_userid +
                ", dish_category_name='" + dish_category_name + '\'' +
                ", main_category_name='" + main_category_name + '\'' +
                ", net_itemtotalprice=" + net_itemtotalprice +
                ", cancel_item_remarks='" + cancel_item_remarks + '\'' +
                ", cancel_item_user_name='" + cancel_item_user_name + '\'' +
                '}';
    }

    public Boolean getCancel() {
        return cancel;
    }

    public void setCancel(Boolean cancel) {
        this.cancel = cancel;
    }

    public Integer getItemqty() {
        return itemqty;
    }

    public void setItemqty(Integer itemqty) {
        this.itemqty = itemqty;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Long getBrand_id() {
        return brand_id;
    }

    public void setBrand_id(Long brand_id) {
        this.brand_id = brand_id;
    }

    public Long getItemcode() {
        return itemcode;
    }

    public void setItemcode(Long itemcode) {
        this.itemcode = itemcode;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public Double getBaseprice() {
        return baseprice;
    }

    public void setBaseprice(Double baseprice) {
        this.baseprice = baseprice;
    }

    public String getDish_type() {
        return dish_type;
    }

    public void setDish_type(String dish_type) {
        this.dish_type = dish_type;
    }

    public Boolean getIs_cancel() {
        return is_cancel;
    }

    public void setIs_cancel(Boolean is_cancel) {
        this.is_cancel = is_cancel;
    }

    public Double getItemprice() {
        return itemprice;
    }

    public void setItemprice(Double itemprice) {
        this.itemprice = itemprice;
    }

    public String getBrand_name() {
        return brand_name;
    }

    public void setBrand_name(String brand_name) {
        this.brand_name = brand_name;
    }

    public Double getCatdiscamt() {
        return catdiscamt;
    }

    public void setCatdiscamt(Double catdiscamt) {
        this.catdiscamt = catdiscamt;
    }

    public Long getCompany_id() {
        return company_id;
    }

    public void setCompany_id(Long company_id) {
        this.company_id = company_id;
    }

    public Double getBilldiscamt() {
        return billdiscamt;
    }

    public void setBilldiscamt(Double billdiscamt) {
        this.billdiscamt = billdiscamt;
    }

    public Boolean getIs_discount() {
        return is_discount;
    }

    public void setIs_discount(Boolean is_discount) {
        this.is_discount = is_discount;
    }

    public Double getItemdiscamt() {
        return itemdiscamt;
    }

    public void setItemdiscamt(Double itemdiscamt) {
        this.itemdiscamt = itemdiscamt;
    }

    public Long getOrdered_qty() {
        return ordered_qty;
    }

    public void setOrdered_qty(Long ordered_qty) {
        this.ordered_qty = ordered_qty;
    }

    public Double getTotaltaxamt() {
        return totaltaxamt;
    }

    public void setTotaltaxamt(Double totaltaxamt) {
        this.totaltaxamt = totaltaxamt;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public Boolean getIs_open_item() {
        return is_open_item;
    }

    public void setIs_open_item(Boolean is_open_item) {
        this.is_open_item = is_open_item;
    }

    public Long getCancelled_qty() {
        return cancelled_qty;
    }

    public void setCancelled_qty(Long cancelled_qty) {
        this.cancelled_qty = cancelled_qty;
    }

    public Double getItemgrossprice() {
        return itemgrossprice;
    }

    public void setItemgrossprice(Double itemgrossprice) {
        this.itemgrossprice = itemgrossprice;
    }

    public Long getDish_category_id() {
        return dish_category_id;
    }

    public void setDish_category_id(Long dish_category_id) {
        this.dish_category_id = dish_category_id;
    }

    public List<Item_Tax_Details> getItem_tax_details() {
        return item_tax_details;
    }

    public void setItem_tax_details(List<Item_Tax_Details> item_tax_details) {
        this.item_tax_details = item_tax_details;
    }

    public Long getMain_category_id() {
        return main_category_id;
    }

    public void setMain_category_id(Long main_category_id) {
        this.main_category_id = main_category_id;
    }

    public Long getCancel_item_userid() {
        return cancel_item_userid;
    }

    public void setCancel_item_userid(Long cancel_item_userid) {
        this.cancel_item_userid = cancel_item_userid;
    }

    public String getDish_category_name() {
        return dish_category_name;
    }

    public void setDish_category_name(String dish_category_name) {
        this.dish_category_name = dish_category_name;
    }

    public String getMain_category_name() {
        return main_category_name;
    }

    public void setMain_category_name(String main_category_name) {
        this.main_category_name = main_category_name;
    }

    public Double getNet_itemtotalprice() {
        return net_itemtotalprice;
    }

    public void setNet_itemtotalprice(Double net_itemtotalprice) {
        this.net_itemtotalprice = net_itemtotalprice;
    }

    public String getCancel_item_remarks() {
        return cancel_item_remarks;
    }

    public void setCancel_item_remarks(String cancel_item_remarks) {
        this.cancel_item_remarks = cancel_item_remarks;
    }

    public String getCancel_item_user_name() {
        return cancel_item_user_name;
    }

    public void setCancel_item_user_name(String cancel_item_user_name) {
        this.cancel_item_user_name = cancel_item_user_name;
    }
}
