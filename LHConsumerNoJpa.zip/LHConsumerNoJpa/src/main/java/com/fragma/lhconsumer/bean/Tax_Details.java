package com.fragma.lhconsumer.bean;

import com.google.gson.annotations.SerializedName;
public class Tax_Details {

    @SerializedName("cgst_2.5")
    private String CGST_2;
    @SerializedName("sgst_2.5")
    private String SGST_2;

    @Override
    public String toString() {
        return "Tax_Details{" +
                "CGST_2='" + CGST_2 + '\'' +
                ", SGST_2='" + SGST_2 + '\'' +
                '}';
    }

    public String getCGST_2() {
        return CGST_2;
    }

    public void setCGST_2(String CGST_2) {
        this.CGST_2 = CGST_2;
    }

    public String getSGST_2() {
        return SGST_2;
    }

    public void setSGST_2(String SGST_2) {
        this.SGST_2 = SGST_2;
    }
}
