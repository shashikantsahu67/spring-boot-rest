package com.fragma.controller;

import com.fragma.beans.Student;
import com.fragma.beans.StudentRegistration;
import com.fragma.beans.StudentRegistrationReply;
import com.fragma.dao.daocontroller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class StudentRegistrationController {

	@RequestMapping(method = RequestMethod.POST, value="/register/reg")
	@ResponseBody
    StudentRegistrationReply registerStudent(@RequestBody Student student) {
		System.out.println("In registerStudent");
        StudentRegistrationReply stdregreply = new StudentRegistrationReply();           

        StudentRegistration.getInstance().add(student);

        //We are setting the below value just to reply a message back to the caller
        stdregreply.setId(student.getId());
        stdregreply.setName(student.getName());
        stdregreply.setAge(student.getAge());
        stdregreply.setRegistrationNumber(student.getRegistrationNumber());
        stdregreply.setPayment_detailsList(student.getPayment_detailsList());
        stdregreply.setRegistrationStatus("Successful");

        daocontroller.setStudentRegistration(stdregreply);
        return stdregreply;
        
	}

}
