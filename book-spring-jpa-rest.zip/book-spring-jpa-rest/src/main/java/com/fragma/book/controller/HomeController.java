package com.fragma.book.controller;

import com.fragma.book.dto.Book;
import com.fragma.book.exception.ResourceNotFoundException;
import com.fragma.book.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
    @Autowired
    BookRepository bookRepository;
    @RequestMapping("home")
    public String sayHello()
    {
        return "home.jsp";
    }
    @RequestMapping("/addBook")
    public String addBook(Book book)
    {
        bookRepository.save(book);
        return "home.jsp";
    }
    @RequestMapping("/getBook")
    public ModelAndView getBook(@RequestParam Long book_id)
    {
        //Long bid=Long.parseLong(book_id);
        ModelAndView mv=new ModelAndView("get.jsp");
        Book book=bookRepository.findById(book_id).orElseThrow(()->new ResourceNotFoundException("Book","book_id",book_id));
        mv.addObject(book);
        return mv;
    }
}
