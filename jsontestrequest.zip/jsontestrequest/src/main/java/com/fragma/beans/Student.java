package com.fragma.beans;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Student {
	private int id;
	private String name;
	private int age;
	private String registrationNumber;
	@JsonProperty("payment_details_list")
	private Student_payment_details payment_detailsList;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Student_payment_details getPayment_detailsList() {
		return payment_detailsList;
	}

	public void setPayment_detailsList(Student_payment_details payment_detailsList) {
		this.payment_detailsList = payment_detailsList;
	}

	@Override
	public String toString() {
		return "Student{" +
				"name='" + name + '\'' +
				", age=" + age +
				", registrationNumber='" + registrationNumber + '\'' +
				'}';
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
}
