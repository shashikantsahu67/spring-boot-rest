package com.fragma.dao;

import com.fragma.beans.StudentRegistrationReply;
import com.fragma.beans.Student_payment_details;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class daocontroller {
      public static  Connection con=null;
        public List<StudentRegistrationReply> getEmployee() {
            List<StudentRegistrationReply> studentList = new ArrayList<>();
            String sql = "select * from employee";
            try {
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(sql);
                while (rs.next()) {
                    StudentRegistrationReply e = new StudentRegistrationReply();
                    e.setId(rs.getInt(1));
                    e.setName(rs.getString(2));
                    e.setAge(rs.getInt(3));
                    e.setRegistrationNumber(rs.getString(4));
                    e.setRegistrationStatus(rs.getString(5));
                    studentList.add(e);
                }
            }

            catch (Exception e) {
                System.out.println(e);
            }
            return studentList;
        }

    public static void setStudentRegistration(StudentRegistrationReply studentRegistration)
    {
        String url = "jdbc:mysql://localhost:3306/world";
        String  username = "root";
        String password = "shashi218";
        PreparedStatement preparedStmt =null;
        PreparedStatement preparedStmt1 =null;
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, username, password);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        int id=studentRegistration.getId();
        String name=studentRegistration.getName();
        int age=studentRegistration.getAge();
        String regnum=studentRegistration.getRegistrationNumber();
        String regstatus=studentRegistration.getRegistrationStatus();
        Student_payment_details payment_detailsList=studentRegistration.getPayment_detailsList();
        //String json =studentRegistration.getPayment_detailsList();
        System.out.println(studentRegistration);
        System.out.println(payment_detailsList);


        String sql1 = "insert into StudentRegistrationReply(id,name,age,registrationNumber,registrationStatus) values(?,?,?,?,?)";
        String sql2="insert into Student_payment_details(pay,date,phcounter) values (?,?,?)";
        // create the mysql insert preparedstatement
        try  {
            preparedStmt = con.prepareStatement(sql1);
            preparedStmt1 = con.prepareStatement(sql2);
            preparedStmt.setInt  (1,id);
            preparedStmt.setString (2, name);
            preparedStmt.setInt (3,age);
            preparedStmt.setString(4, regnum);
            preparedStmt.setString(5,regstatus);
           /* preparedStmt1.setInt(1,payment_detailsList.get(0).getPay());
            preparedStmt1.setString(2,payment_detailsList.get(1).getDate());
            preparedStmt1.setString(3,payment_detailsList.get(2).getPhcounter());*/
            // execute the preparedstatement
            preparedStmt.execute();
            preparedStmt1.execute();

            System.out.println("data sucessfully inserted .......");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }

    }


}
