package com.postmanrest.controller;

import com.postmanrest.bean.Person;
import com.postmanrest.exception.ResourceNotFoundException;
import com.postmanrest.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class PersonController {

    @Autowired
    PersonRepository personRepository;
    @RequestMapping("/getp")
    public Person savePersons(@RequestBody Person person)
    {
        personRepository.save(person);
        return person;
    }
    @GetMapping("/getall")
    public List<Person> getAllPerson()
    {
        return personRepository.findAll();
    }
    @RequestMapping("/get/{pid}")
    @ResponseBody
    public Optional<Person> getPersonById(@PathVariable("pid") int pid)
    {
        return personRepository.findById(pid);
    }

    @DeleteMapping("/delete/{pid}")
    public String deletePerson(@PathVariable int pid){
        Person p=personRepository.getOne(pid);
        personRepository.delete(p);
        return "deleted...."+pid;
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Object> updateStudent(@RequestBody Person person, @PathVariable int id) {

        Optional<Person> personOptional = personRepository.findById(id);

        if (!personOptional.isPresent())
            return ResponseEntity.notFound().build();

        person.setPid(id);

        personRepository.save(person);

        return ResponseEntity.noContent().build();
    }

    @RequestMapping("/byaddress/{address}")
    public List<Person> findByAddress(@PathVariable String address)
    {
        List<Person> person=personRepository.findAllByAddress(address);
        return person;
    }
}
