package com.fragma.lhconsumer.bean;

import com.google.gson.annotations.SerializedName;
public class Item_Tax_Details {


    @SerializedName("cgst.5")
    private Double cgst;
    @SerializedName("sgst.5")
    private Double sgst;

    @Override
    public String toString() {
        return "Item_Tax_Details{" +
                "cgst=" + cgst +
                ", sgst=" + sgst +
                '}';
    }

    public Double getCgst() {
        return cgst;
    }

    public void setCgst(Double cgst) {
        this.cgst = cgst;
    }

    public Double getSgst() {
        return sgst;
    }

    public void setSgst(Double sgst) {
        this.sgst = sgst;
    }
}
