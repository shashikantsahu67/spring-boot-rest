/*
package com.fragma.controller;

import com.fragma.bean.PlaneCrashInfo;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class FileReaderr {
    FileWriter fileWriter;
    String file = "C:\\Users\\LENOVO\\Documents\\planecrashinfo.csv";
    PlaneCrashInfo planeCrashInfo = null;
    HashMap<Integer, PlaneCrashInfo> hashMap = new HashMap<Integer, PlaneCrashInfo>();
    //  List<PlaneCrashInfo> crashInfoList=new ArrayList<PlaneCrashInfo>();
    int AlPass = 0;
    int index = 1;
        try {
        fileWriter = new FileWriter(file);
        fileWriter.append(FILE_HEADER);
        fileWriter.append(NEW_LINE_SEPARATOR);
        for (int j = 1920; j <= 2019; j++) {
            String url = "http://www.planecrashinfo.com/" + j + "/" + j + ".htm";
            Document doc = Jsoup.connect(url).get();
            Element table = doc.select("table").get(0); //select the first table.
            Elements rows = table.select("tr");
            SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy");
            for (int i = 1; i < rows.size(); i++) { //first row is the col names so skip it.
                Element row = rows.get(i);
                Elements cols = row.select("td");
                String fatal = cols.get(3).text();
                String[] Pass = fatal.split("/", 2);
                int DPass = 0;
                String APass = Pass[1];
                String[] AllPass = APass.split("\\(", 2);
                String date = cols.get(0).text();
                Date d = formatter.parse(date);
                planeCrashInfo = new PlaneCrashInfo(d, cols.get(1).text(), cols.get(2).text(), DPass, AlPass);
                hashMap.put(index, planeCrashInfo);
                //crashInfoList.add(planeCrashInfo);
                // System.out.println(planeCrashInfo);
                if (AllPass[0].trim().equals("?") || Pass[0].trim().equals("?")) {
                    AlPass = 0;
                    DPass = 0;

                } else {
                    AlPass = Integer.parseInt(AllPass[0]);
                    DPass = Integer.parseInt(Pass[0]);
                }
                fileWriter.append(String.valueOf(index));
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(cols.get(0).text());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(cols.get(1).text().replaceAll(",", "/"));
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(cols.get(2).text().replaceAll("\\?", ""));
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(String.valueOf(DPass));
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(String.valueOf(AlPass));
                fileWriter.append(NEW_LINE_SEPARATOR);
                index++;
                // System.out.println(cols.get(0).text());
            }
            // index++;
        }
    } catch (
    IOException e) {
        e.printStackTrace();
    } catch (NumberFormatException nu) {

    } catch (
    ParseException p) {
        p.printStackTrace();
    }
        return hashMap;
}
*/
